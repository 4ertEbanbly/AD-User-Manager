﻿param(
    [string]$Domain = "",
    [string]$DefaultPath = ""
)

# Автоматическое определение домена
try {
    Import-Module ActiveDirectory -ErrorAction Stop
    Write-Host "Модуль Active Directory загружен" -ForegroundColor Green
    
    if ([string]::IsNullOrEmpty($Domain)) {
        $domainInfo = Get-ADDomain
        $Domain = $domainInfo.DNSRoot
        Write-Host "Автоматически определен домен: $Domain" -ForegroundColor Green
    }
    
    if ([string]::IsNullOrEmpty($DefaultPath)) {
        $domainInfo = Get-ADDomain
        $DefaultPath = "OU=ADScript-Users," + $domainInfo.DistinguishedName
        Write-Host "Автоматически установлен путь по умолчанию: $DefaultPath" -ForegroundColor Green
    }
} catch {
    Write-Host "Ошибка определения домена: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

$ScriptDirectory = "$env:USERPROFILE\Documents\ADscript"
$LogsDirectory = "$ScriptDirectory\logs"
$LogFileName = "logs_AD_create_delete_$(Get-Date -Format 'yyyyMMdd_HHmmss').txt"
$LogPath = "$LogsDirectory\$LogFileName"

try {
    if (!(Test-Path $ScriptDirectory)) {
        New-Item -ItemType Directory -Path $ScriptDirectory -Force | Out-Null
        Write-Host "Создана директория скрипта: $ScriptDirectory" -ForegroundColor Green
    }
    if (!(Test-Path $LogsDirectory)) {
        New-Item -ItemType Directory -Path $LogsDirectory -Force | Out-Null
        Write-Host "Создана директория логов: $LogsDirectory" -ForegroundColor Green
    }
} catch {
    Write-Host "Ошибка создания структуры папок: $($_.Exception.Message)" -ForegroundColor Red
}

function Write-Log {
    param(
        [string]$Message, 
        [string]$Level = "INFO",
        [string]$UserAction = $null
    )
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $currentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
    $userActionText = if ($UserAction) { " | Действие: $UserAction" } else { "" }
    
    $logEntry = "[$timestamp] [$Level] [Пользователь: $currentUser]$userActionText - $Message"
    
    try {
        if (!(Test-Path $LogsDirectory)) {
            New-Item -ItemType Directory -Path $LogsDirectory -Force | Out-Null
        }
        Add-Content -Path $LogPath -Value $logEntry -Encoding UTF8
    } catch {
        try {
            $tempLog = "$env:TEMP\ad_management_temp.log"
            Add-Content -Path $tempLog -Value $logEntry -Encoding UTF8
            Write-Host "Ошибка записи в основной лог. Используется временный файл: $tempLog" -ForegroundColor Yellow
        } catch {
            Write-Host "Критическая ошибка логирования: $logEntry" -ForegroundColor Red
        }
    }
    
    switch ($Level) {
        "ERROR" { Write-Host $logEntry -ForegroundColor Red }
        "WARNING" { Write-Host $logEntry -ForegroundColor Yellow }
        "SUCCESS" { Write-Host $logEntry -ForegroundColor Green }
        "AUDIT" { Write-Host $logEntry -ForegroundColor Cyan }
        default { Write-Host $logEntry -ForegroundColor White }
    }
}

function Write-Audit {
    param([string]$Action, [string]$Target, [string]$Details = "")
    Write-Log "АУДИТ: $Action - Объект: $Target - $Details" -Level "AUDIT" -UserAction $Action
}

try {
    $domainInfo = Get-ADDomain
    Write-Log "Подключено к домену: $($domainInfo.DNSRoot)" -Level "SUCCESS"
} catch {
    Write-Log "Нет подключения к домену Active Directory" -Level "ERROR"
    exit 1
}

function Get-AvailableOUs {
    try {
        $domainDN = (Get-ADDomain).DistinguishedName
        $allOUs = Get-ADOrganizationalUnit -Filter * -SearchBase $domainDN | 
                   Select-Object Name, DistinguishedName | 
                   Sort-Object Name
        
        $domainOU = [PSCustomObject]@{
            Name = "Корень домена"
            DistinguishedName = $domainDN
        }
        
        return @($domainOU) + $allOUs
    } catch {
        Write-Log "Ошибка получения списка OU: $($_.Exception.Message)" -Level "ERROR"
        return @()
    }
}

function Select-TargetOU {
    Write-Host "`nВЫБОР ПОДРАЗДЕЛЕНИЯ (OU)" -ForegroundColor Cyan
    
    $availableOUs = Get-AvailableOUs
    
    if ($availableOUs.Count -eq 0) {
        Write-Host "Не удалось получить список OU. Будет использовано подразделение по умолчанию." -ForegroundColor Yellow
        return $DefaultPath
    }
    
    Write-Host "`nДоступные подразделения:" -ForegroundColor Green
    Write-Host "`n"
    for ($i = 0; $i -lt $availableOUs.Count; $i++) {
        Write-Host "$($i + 1). $($availableOUs[$i].Name)" -ForegroundColor White
        Write-Host "   Путь: $($availableOUs[$i].DistinguishedName)" -ForegroundColor Gray
    }
    
    Write-Host "`n0. Использовать путь по умолчанию" -ForegroundColor Yellow
    
    while ($true) {
        $choice = Read-Host "`nВыберите номер подразделения (0-$($availableOUs.Count))"
        
        if ($choice -eq "0") {
            return $DefaultPath
        }
        elseif ($choice -match '^\d+$' -and [int]$choice -le $availableOUs.Count -and [int]$choice -ge 1) {
            $selectedOU = $availableOUs[[int]$choice - 1].DistinguishedName
            Write-Host "Выбрано подразделение: $selectedOU" -ForegroundColor Green
            return $selectedOU
        }
        else {
            Write-Host "Некорректный выбор. Пожалуйста, введите число от 0 до $($availableOUs.Count)" -ForegroundColor Red
        }
    }
}

function Test-AndCreateOU {
    param([string]$TargetPath = $DefaultPath)
    
    try {
        if ($TargetPath -eq (Get-ADDomain).DistinguishedName) {
            Write-Log "Используется корень домена: $TargetPath" -Level "SUCCESS"
            return $true
        }
        
        Get-ADOrganizationalUnit -Identity $TargetPath | Out-Null
        Write-Log "OU '$TargetPath' существует" -Level "SUCCESS"
        return $true
    } catch {
        Write-Log "OU '$TargetPath' не существует. Создаю..." -Level "WARNING"
        try {
            $ouName = ($TargetPath -split ',', 2)[0] -replace '^OU=',''
            $parentPath = ($TargetPath -split ',', 2)[1]
            
            New-ADOrganizationalUnit -Name $ouName -Path $parentPath -ProtectedFromAccidentalDeletion $false
            Write-Log "OU '$TargetPath' успешно создан" -Level "SUCCESS"
            return $true
        } catch {
            Write-Log "Ошибка создания OU '$TargetPath': $($_.Exception.Message)" -Level "ERROR"
            return $false
        }
    }
}

#Проверка уникальности логина
function Test-SamAccountName {
    param([string]$SamAccountName)
    try {
        $existingUser = Get-ADUser -Filter "SamAccountName -eq '$SamAccountName'" -ErrorAction SilentlyContinue
        return ($existingUser -eq $null)
    } catch {
        return $false
    }
}

#Проверка членства в группе
function Test-UserInGroup {
    param([string]$UserName, [string]$GroupName)
    try {
        $members = Get-ADGroupMember -Identity $GroupName -ErrorAction Stop
        foreach ($member in $members) {
            if ($member.SamAccountName -eq $UserName) {
                return $true
            }
        }
        return $false
    } catch {
        return $false
    }
}

#Получение групп домена
function Get-DomainGroups {
    try {
        $groups = Get-ADGroup -Filter * -Properties Description | 
                  Select-Object Name, Description, GroupCategory |
                  Sort-Object Name
        
        $commonGroups = $groups | Where-Object { 
            $_.Name -match "пользовател|user|admin|администратор|operator|оператор|guest|гость" -or
            $_.GroupCategory -eq "Security"
        } | Select-Object -First 20
        
        return $commonGroups.Name
    } catch {
        Write-Log "Ошибка получения списка групп: $($_.Exception.Message)" -Level "ERROR"
        return @("Domain Users", "Domain Admins")
    }
}

#Проверка номера телефона
function Test-PhoneNumber {
    param([string]$Phone)
    if ([string]::IsNullOrWhiteSpace($Phone)) {
        return $true
    }
    return $Phone -match '^[\+]?[\(\-\s]?[\d\-\s\(\)]{10,}$'
}

#Создание пользователя
function New-ADUserInteractive {
    Write-Host "--------------------------------" -ForegroundColor Cyan
    Write-Host "СОЗДАНИЕ НОВОГО ПОЛЬЗОВАТЕЛЯ AD" -ForegroundColor Cyan
    Write-Host "--------------------------------" -ForegroundColor Cyan
    
    $targetOU = Select-TargetOU
    
    if (-not (Test-AndCreateOU -TargetPath $targetOU)) {
        Write-Host "Не удалось проверить/создать OU. Создание пользователя прервано." -ForegroundColor Red
        return $false
    }
    
    do {
        $username = Read-Host "Введите логин пользователя"
        if ([string]::IsNullOrWhiteSpace($username)) {
            Write-Host "Логин не может быть пустым" -ForegroundColor Red
            continue
        }
        
        if (Test-SamAccountName -SamAccountName $username) {
            break
        } else {
            Write-Host "Пользователь $username уже существует" -ForegroundColor Red
        }
    } while ($true)
    
    $firstName = Read-Host "Введите имя"
    $lastName = Read-Host "Введите фамилию" 
    $displayName = "$firstName $lastName"
    $name = "$firstName $lastName ($username)"
    
    $email = Read-Host "Введите email адрес"
    if ([string]::IsNullOrWhiteSpace($email)) {
        $email = "$username@$Domain"
    }
    
    $department = Read-Host "Введите отдел (или Enter для пропуска)"
    $title = Read-Host "Введите должность (или Enter для пропуска)"
    
    do {
        $phone = Read-Host "Введите номер телефона (или Enter для пропуска)"
        if (-not [string]::IsNullOrWhiteSpace($phone) -and -not (Test-PhoneNumber -Phone $phone)) {
            Write-Host "Некорректный формат номера телефона" -ForegroundColor Red
            continue
        }
        break
    } while ($true)
    
    $description = Read-Host "Введите описание пользователя (или Enter для пропуска)"
    
    Write-Host "`nДоступные группы:" -ForegroundColor Cyan
    $availableGroups = Get-DomainGroups
    for ($i = 0; $i -lt $availableGroups.Count; $i++) {
        Write-Host "  $($i + 1). $($availableGroups[$i])"
    }
    
    $selectedGroups = @()
    while ($true) {
        $choice = Read-Host "`nВведите номер группы для добавления (или Enter для завершения)"
        if ([string]::IsNullOrWhiteSpace($choice)) {
            break
        }
        
        if ($choice -match '^\d+$' -and [int]$choice -le $availableGroups.Count -and [int]$choice -ge 1) {
            $groupName = $availableGroups[[int]$choice - 1]
            try {
                $groupExists = Get-ADGroup -Filter "Name -eq '$groupName'"
                if ($groupExists) {
                    $selectedGroups += $groupName
                    Write-Host "Группа добавлена в список: $groupName" -ForegroundColor Green
                } else {
                    Write-Host "Группа $groupName не найдена" -ForegroundColor Red
                }
            } catch {
                Write-Host "Ошибка проверки группы $groupName" -ForegroundColor Red
            }
        } else {
            Write-Host "Некорректный выбор" -ForegroundColor Red
        }
    }
    
    Write-Host "`nНастройка пароля:" -ForegroundColor Cyan
    Write-Host "1. Сгенерировать автоматически"
    Write-Host "2. Ввести вручную"
    
    $passChoice = Read-Host "Выберите опцию (1 или 2)"
    if ($passChoice -eq "1") {
        $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%"
        $password = -join ((1..12) | ForEach-Object { $chars[(Get-Random -Maximum $chars.Length)] })
        $securePassword = ConvertTo-SecureString $password -AsPlainText -Force
        $changePasswordAtLogon = $true
    } else {
        do {
            $securePassword = Read-Host "Введите пароль" -AsSecureString
            $passwordConfirm = Read-Host "Подтвердите пароль" -AsSecureString
            
            $plainPassword1 = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePassword))
            $plainPassword2 = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($passwordConfirm))
            
            if ($plainPassword1 -eq $plainPassword2) {
                $password = "*** введен вручную ***"
                $changePasswordAtLogon = $false
                break
            } else {
                Write-Host "Пароли не совпадают. Попробуйте снова." -ForegroundColor Red
            }
        } while ($true)
    }
    
    Write-Host "`nПОДТВЕРЖДЕНИЕ СОЗДАНИЯ ПОЛЬЗОВАТЕЛЯ" -ForegroundColor Yellow
    Write-Host "`n"
    Write-Host "Логин: $username"
    Write-Host "Имя: $firstName $lastName"
    Write-Host "Email: $email"
    Write-Host "Телефон: $phone"
    Write-Host "Подразделение: $targetOU"
    Write-Host "Группы: $($selectedGroups -join ', ')"
    Write-Host "Смена пароля при входе: $(if ($changePasswordAtLogon) { 'Да' } else { 'Нет' })"
    if ($passChoice -eq "1") {
        Write-Host "Пароль: $password" -ForegroundColor Magenta
    } else {
        Write-Host "Пароль: ******" -ForegroundColor Magenta
    }
    
    $confirm = Read-Host "`nСоздать пользователя? (Y/N)"
    if ($confirm -notmatch '^[Yy]') {
        Write-Log "Создание пользователя $username отменено" -Level "WARNING"
        Write-Host "Создание отменено" -ForegroundColor Yellow
        return $false
    }
    
    try {
        Write-Host "`nСоздание пользователя..." -ForegroundColor Cyan
        
        $userParams = @{
            SamAccountName = $username
            Name = $name
            GivenName = $firstName
            Surname = $lastName
            DisplayName = $displayName
            UserPrincipalName = "$username@$Domain"
            EmailAddress = $email
            AccountPassword = $securePassword
            Enabled = $true
            ChangePasswordAtLogon = $changePasswordAtLogon
            Path = $targetOU
        }
        
        if (-not [string]::IsNullOrWhiteSpace($department)) {
            $userParams.Department = $department
        }
        
        if (-not [string]::IsNullOrWhiteSpace($title)) {
            $userParams.Title = $title
        }
        
        if (-not [string]::IsNullOrWhiteSpace($phone)) {
            $userParams.OfficePhone = $phone
        }
        
        if (-not [string]::IsNullOrWhiteSpace($description)) {
            $userParams.Description = $description
        }
        
        New-ADUser @userParams
        Write-Log "Пользователь $username успешно создан в OU: $targetOU" -Level "SUCCESS"
        Write-Host "✓ Пользователь $username успешно создан!" -ForegroundColor Green
        
        if ($selectedGroups.Count -gt 0) {
            Write-Host "Добавление в группы..." -ForegroundColor Cyan
            foreach ($group in $selectedGroups) {
                try {
                    if (Test-UserInGroup -UserName $username -GroupName $group) {
                        Write-Host "  ✓ Пользователь уже в группе: $group" -ForegroundColor Yellow
                    } else {
                        Add-ADGroupMember -Identity $group -Members $username -ErrorAction Stop
                        Write-Log "Пользователь $username добавлен в группу $group" -Level "SUCCESS"
                        Write-Host "  ✓ Добавлен в группу: $group" -ForegroundColor Green
                    }
                } catch [Microsoft.ActiveDirectory.Management.ADIdentityAlreadyExistsException] {
                    Write-Host "  ✓ Пользователь уже в группе: $group" -ForegroundColor Yellow
                } catch {
                    Write-Log "Ошибка добавления пользователя $username в группу $group : $($_.Exception.Message)" -Level "ERROR"
                    Write-Host "  ✗ Ошибка добавления в группу $group : $($_.Exception.Message)" -ForegroundColor Red
                }
            }
        }
        
        if ($passChoice -eq "1") {
            Write-Host "`nСГЕНЕРИРОВАННЫЙ ПАРОЛЬ: $password" -ForegroundColor Magenta
            Write-Host "Пользователь должен сменить пароль при следующем входе!" -ForegroundColor Magenta
        }
        
        return $true
        
    } catch {
        Write-Log "Ошибка создания пользователя $username : $($_.Exception.Message)" -Level "ERROR"
        Write-Host "✗ Ошибка создания пользователя: $($_.Exception.Message)" -ForegroundColor Red
        return $false
    }
}

#Удаление пользователя
function Remove-ADUserInteractive {
    Write-Host "------------------------" -ForegroundColor Red
    Write-Host "УДАЛЕНИЕ ПОЛЬЗОВАТЕЛЯ AD" -ForegroundColor Red
    Write-Host "------------------------" -ForegroundColor Red
    
    $targetOU = Select-TargetOU
    
    try {
        $users = Get-ADUser -Filter * -SearchBase $targetOU | 
                 Select-Object Name, SamAccountName, Enabled |
                 Sort-Object Name
        
        if ($users.Count -eq 0) {
            Write-Host "В выбранном OU '$targetOU' нет пользователей" -ForegroundColor Yellow
            return
        }
        
        Write-Host "`nСписок пользователей в OU '$targetOU':" -ForegroundColor Cyan
        Write-Host "№  Имя пользователя          Логин               Статус"
        Write-Host "`n"
        
        for ($i = 0; $i -lt $users.Count; $i++) {
            $status = if ($users[$i].Enabled) { "Активен" } else { "Отключен" }
            Write-Host "$($i+1). $($users[$i].Name.PadRight(25)) $($users[$i].SamAccountName.PadRight(18)) $status"
        }
    } catch {
        Write-Host "Ошибка при получении списка пользователей из OU '$targetOU': $($_.Exception.Message)" -ForegroundColor Red
        return
    }
    
    while ($true) {
        $choice = Read-Host "`nВведите номер пользователя для удаления (или Enter для отмены)"
        
        if ([string]::IsNullOrWhiteSpace($choice)) {
            Write-Host "Удаление отменено" -ForegroundColor Yellow
            return
        }
        
        if ($choice -match '^\d+$' -and [int]$choice -le $users.Count -and [int]$choice -ge 1) {
            $selectedUser = $users[[int]$choice - 1]
            break
        } else {
            Write-Host "Некорректный номер" -ForegroundColor Red
        }
    }
    
    Write-Host "`n"
    Write-Host "ВНИМАНИЕ: Будет удален пользователь:" -ForegroundColor Red
    Write-Host "Имя: $($selectedUser.Name)" -ForegroundColor Red
    Write-Host "Логин: $($selectedUser.SamAccountName)" -ForegroundColor Red
    Write-Host "Из подразделения: $targetOU" -ForegroundColor Red
    Write-Host "`n"
    
    $confirm = Read-Host "`nВы уверены, что хотите удалить этого пользователя? (Y/N)"
    if ($confirm -notmatch '^[Yy]') {
        Write-Host "Удаление отменено" -ForegroundColor Yellow
        return
    }
    
    try {
        Remove-ADUser -Identity $selectedUser.SamAccountName -Confirm:$false
        Write-Log "Пользователь $($selectedUser.SamAccountName) удален из OU: $targetOU" -Level "SUCCESS"
        Write-Host "✓ Пользователь $($selectedUser.SamAccountName) успешно удален из подразделения: $targetOU" -ForegroundColor Green
    } catch {
        Write-Log "Ошибка удаления пользователя $($selectedUser.SamAccountName) из OU $targetOU : $($_.Exception.Message)" -Level "ERROR"
        Write-Host "✗ Ошибка удаления пользователя: $($_.Exception.Message)" -ForegroundColor Red
    }
}

#Сброс пароля пользователя
function Reset-ADUserPassword {
    Write-Host "`n"
    Write-Host "СБРОС ПАРОЛЯ ПОЛЬЗОВАТЕЛЯ" -ForegroundColor Magenta
    Write-Host "`n"
    
    $username = Read-Host "Введите логин пользователя"
    
    try {
        $user = Get-ADUser -Identity $username -ErrorAction Stop
        
        Write-Host "`nПользователь найден:" -ForegroundColor Cyan
        Write-Host "Имя: $($user.Name)"
        Write-Host "Логин: $($user.SamAccountName)"
        Write-Host "Email: $($user.EmailAddress)"
        Write-Host "Подразделение: $($user.DistinguishedName -replace '^CN=.*?,(.*)$', '$1')"
        
        $confirm = Read-Host "`nСбросить пароль для этого пользователя? (Y/N)"
        if ($confirm -notmatch '^[Yy]') {
            Write-Host "Сброс пароля отменен" -ForegroundColor Yellow
            return
        }
        
        $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%"
        $newPassword = -join ((1..12) | ForEach-Object { $chars[(Get-Random -Maximum $chars.Length)] })
        $securePassword = ConvertTo-SecureString $newPassword -AsPlainText -Force
        
        Set-ADAccountPassword -Identity $username -NewPassword $securePassword -Reset
        Set-ADUser -Identity $username -ChangePasswordAtLogon $true
        
        Write-Log "Пароль пользователя $username сброшен" -Level "SUCCESS"
        Write-Host "`n"
        Write-Host "НОВЫЙ ПАРОЛЬ: $newPassword" -ForegroundColor Magenta
        Write-Host "Пользователь должен сменить пароль при следующем входе!" -ForegroundColor Magenta
        Write-Host "`n"
        
    } catch {
        Write-Log "Ошибка сброса пароля для $username : $($_.Exception.Message)" -Level "ERROR"
        Write-Host "✗ Ошибка: $($_.Exception.Message)" -ForegroundColor Red
    }
}

function Show-Statistics {
    Write-Host "------------------------" -ForegroundColor Blue
    Write-Host "СТАТИСТИКА ПОЛЬЗОВАТЕЛЕЙ" -ForegroundColor Blue
    Write-Host "------------------------" -ForegroundColor Blue
    
    $targetOU = Select-TargetOU
    
    try {
        $users = Get-ADUser -Filter * -SearchBase $targetOU
        $enabledUsers = $users | Where-Object { $_.Enabled -eq $true }
        $disabledUsers = $users | Where-Object { $_.Enabled -eq $false }
        
        Write-Host "`nСТАТИСТИКА подразделения: $targetOU" -ForegroundColor Blue
        Write-Host "`n"
        Write-Host "Всего пользователей: $($users.Count)" -ForegroundColor White
        Write-Host "Активных: $($enabledUsers.Count)" -ForegroundColor Green
        Write-Host "Отключенных: $($disabledUsers.Count)" -ForegroundColor Yellow
        Write-Host "`n"
        
        if ($users.Count -gt 0) {
            Write-Host "`nПоследние 5 созданных пользователей:" -ForegroundColor Cyan
            $users | Sort-Object WhenCreated -Descending | Select-Object -First 5 | 
                Format-Table Name, SamAccountName, WhenCreated -AutoSize
        }
    } catch {
        Write-Host "Ошибка получения статистики для OU '$targetOU': $($_.Exception.Message)" -ForegroundColor Red
    }
}

function Show-MainMenu {
    do {
        Write-Host "`n==========================================" -ForegroundColor Green
        Write-Host "УПРАВЛЕНИЕ ПОЛЬЗОВАТЕЛЯМИ ACTIVE DIRECTORY" -ForegroundColor Green
        Write-Host "==========================================" -ForegroundColor Green
		Write-Host "Автоматически определен домен: $Domain" -ForegroundColor Gray
        Write-Host "`n1. Создать нового пользователя"
        Write-Host "2. Удалить пользователя"
        Write-Host "3. Сбросить пароль пользователя"
        Write-Host "4. Показать статистику"
        Write-Host "5. Выход"
        Write-Host "`n"
        
        $choice = Read-Host "`nВыберите действие (1-5)"
        
        switch ($choice) {
            "1" { New-ADUserInteractive }
            "2" { Remove-ADUserInteractive }
            "3" { Reset-ADUserPassword }
            "4" { Show-Statistics }
            "5" { 
                Write-Host "Выход из программы..." -ForegroundColor Yellow
                exit 
            }
            default { Write-Host "Некорректный выбор" -ForegroundColor Red }
        }
        
        if ($choice -ne "5") {
            $continue = Read-Host "`nВернуться в главное меню? (Y/N)"
            if ($continue -notmatch '^[Yy]') {
                Write-Host "Выход из программы..." -ForegroundColor Yellow
                exit
            }
        }
    } while ($true)
}

#Основной процесс
Write-Log "Запуск скрипта управления пользователями AD" -Level "INFO"
Write-Log "Автоматически определен домен: $Domain" -Level "INFO"
Write-Log "Путь к логам: $LogPath" -Level "INFO"

Show-MainMenu

Write-Log "Завершение работы скрипта" -Level "INFO"
Write-Host "`nРабота скрипта завершена!" -ForegroundColor Green
Write-Host "Логи сохранены: $LogPath" -ForegroundColor Gray